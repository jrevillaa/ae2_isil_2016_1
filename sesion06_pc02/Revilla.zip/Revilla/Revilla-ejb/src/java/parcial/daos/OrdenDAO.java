package parcial.daos;

import parcial.beans.Elemento;
import java.util.Vector;

public class OrdenDAO {
    public boolean generarOrden(String cli_codigo,double mt,Vector<Elemento> carrito){
         //conexion a la base de datos


         //captura de la fecha de la transaccion

        //generar correlativo de orden

        //Realizar insert en la tabla ordenes
        //nro de orden
        //fecha de transaccion
        //monto
        //estado G = generada   A= anulada   P= procesada
        //codigo del cliente
        
        //***************Pasos para generar detalle de la orden
        //realizar un for para recorrer el carrito
        //ejecutar un insert por cada elemento


        return false;
    }


}
